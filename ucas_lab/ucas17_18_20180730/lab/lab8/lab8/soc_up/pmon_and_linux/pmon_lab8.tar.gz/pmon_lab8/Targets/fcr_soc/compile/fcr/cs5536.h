#define	NCS5536	0
#define	NPCI	1
#define	NKB3310	0
