#define	NMOD_TOD	0
#define	NHAVE_TOD	0
#define	NCMD_DATE	1
