#define	NMOD_SMI712	0
