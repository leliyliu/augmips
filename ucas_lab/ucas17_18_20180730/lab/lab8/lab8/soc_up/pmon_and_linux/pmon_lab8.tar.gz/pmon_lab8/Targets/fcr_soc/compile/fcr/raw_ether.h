#define	NRAW_ETHER	0
