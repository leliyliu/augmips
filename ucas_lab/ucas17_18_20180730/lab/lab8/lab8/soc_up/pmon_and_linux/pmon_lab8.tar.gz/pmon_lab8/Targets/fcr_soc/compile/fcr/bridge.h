#define	NBRIDGE	0
