#define	NMOD_SYMBOLS	1
#define	NCMD_SYM	0
