#define	NNAND_BCH	0
