int dg_ctrl(int argc, char argv[][30]);
