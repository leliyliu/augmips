int putchar(unsigned char c)
{
tgt_putchar(c);
return 0;
}
