void TIMER_INT();
void KEY_INT();
void BAT_FAIL();
void RES_VALID();
void INTC();
void Ring();
void Per_timer(struct Data *Lcd_data);

void Interrupt_Init();
