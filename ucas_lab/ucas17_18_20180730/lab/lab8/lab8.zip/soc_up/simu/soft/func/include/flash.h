// CONFIDENTIAL

int verif(int argc, char argv[][30]);
int set_pe_time_mode(int argc, char argv[][30]);
int flash_tk(int argc, char argv[][30]);
int flash_accg(int argc, char argv[][30]);
