
void ADC_Init(void);
void BatteryTest1();
void BatteryTest2();
