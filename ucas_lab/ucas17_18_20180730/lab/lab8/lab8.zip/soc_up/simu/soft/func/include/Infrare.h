void Infrare(void);
