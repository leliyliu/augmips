
_fp32 bubble_sort(_fp32 *delta, _s32 len);
void UintToBcd(_u32 dat, _u8 *bcd_buf);
void BcdToUint(_u8 *bcd_buf, _u32 dat);
_s32 printf_float(_fp32 data);
