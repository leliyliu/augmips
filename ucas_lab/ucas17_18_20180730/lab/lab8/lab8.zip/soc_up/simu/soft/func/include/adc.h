
float BatteryMeasure(void)
