void Key(struct Data *Lcd_data);
